from django.shortcuts import render
from django.views.generic import TemplateView
from django.views.generic import (
    ListView,
    DetailView
)
from .models import *


class ProgrammListView(ListView):
    model = Program
    template_name = 'programs/programs.html'
    context_object_name = 'program_list'
    paginate_by = 6

    def get_queryset(self):

        queryset = Program.objects.all()

        sent_country = self.request.GET.get('country')
        sent_category = self.request.GET.get('category')

        if sent_country and sent_category:
            sent_country=int(sent_country)
            sent_category=int(sent_category)
            queryset=queryset.filter(country=sent_country,category=sent_category)

        elif sent_country:
            sent_country = int(sent_country)
            queryset = queryset.filter(country=sent_country)

        elif sent_category:
            sent_category=int(sent_category)
            queryset=queryset.filter(category=sent_category)


        return queryset




class ProgramDetailView(DetailView):
    model = Program
    template_name = 'programs/program_detail.html'
