from django.db import models
from wagtail.admin.edit_handlers import FieldPanel
from wagtail.images.edit_handlers import ImageChooserPanel

from common.models import Base
from wagtail.core.fields import RichTextField

class ProgramCategory(Base):
    name=models.CharField(max_length=255,blank=True,null=True)

    def __str__(self):
        return self.name


class ProgramCountry(Base):
    name=models.CharField(max_length=255,blank=True,null=True)

    def __str__(self):
        return self.name

class Program(Base):
    title = models.CharField("Dastur Nomi",max_length=255)
    short_description = RichTextField("Dasturning qisqa tafsifi")
    full_description = RichTextField("Dasturning to'liq tafsifi")
    img = models.ImageField("rasm",default='default.jpg', upload_to='program_images')
    category=models.ForeignKey(ProgramCategory,on_delete=models.CASCADE)
    country=models.ForeignKey(ProgramCountry,on_delete=models.CASCADE)


    class Meta:
        verbose_name = 'Dastur'
        verbose_name_plural = "Dasturlar"

    panels = [
        FieldPanel('title'),
        FieldPanel('category'),
        FieldPanel('country'),
        FieldPanel('short_description'),
        FieldPanel('full_description'),
        FieldPanel('img'),
    ]

    def __str__(self):
        return self.title

class ProgramSlider(Base):
    title=models.CharField(max_length=255)
    img = models.ImageField("rasm",default='default.jpg', upload_to='program_images')
