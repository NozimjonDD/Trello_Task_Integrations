from django.urls import path
from .views import *

app_name = 'programms'
urlpatterns = [
    path('', ProgrammListView.as_view(), name='programms'),
    path('program_detail/<int:pk>/', ProgramDetailView.as_view(), name='program_detail')
]
