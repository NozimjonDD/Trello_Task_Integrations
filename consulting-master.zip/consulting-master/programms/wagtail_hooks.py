from wagtail.contrib.modeladmin.options import (
    ModelAdmin, modeladmin_register)
from .models import *


class ProgramAdmin(ModelAdmin):
    model = Program
    menu_label = 'Dastur'  # ditch this to use verbose_name_plural from model
    menu_icon = 'pilcrow'  # change as required
    menu_order = 2  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view
    list_display = ('id', 'title')
    # list_filter = ('id','title')
    search_fields = ('id','title')

class ProgramSliderAdmin(ModelAdmin):
    model = ProgramSlider
    menu_label = 'Slayder(Dastur)'  # ditch this to use verbose_name_plural from model
    menu_icon = 'image'  # change as required
    menu_order = 13  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view
    list_display = ('id', 'title')
    # list_filter = ('id','title')
    search_fields = ('id','title')

class ProgramCategoryAdmin(ModelAdmin):
    model = ProgramCategory
    menu_label = 'Dastru(Kategoriya)'  # ditch this to use verbose_name_plural from model
    menu_icon = 'image'  # change as required
    menu_order = 15  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view
    list_display = ('id', 'name')
    # list_filter = ('id','title')
    search_fields = ('id','name')

class ProgramCountryAdmin(ModelAdmin):
    model = ProgramCountry
    menu_label = 'Mamlakatlar'  # ditch this to use verbose_name_plural from model
    menu_icon = 'image'  # change as required
    menu_order = 16 # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view
    list_display = ('id', 'name')
    # list_filter = ('id','title')
    search_fields = ('id','name')


modeladmin_register(ProgramAdmin)
modeladmin_register(ProgramSliderAdmin)
modeladmin_register(ProgramCategoryAdmin)
modeladmin_register(ProgramCountryAdmin)


