from django.apps import AppConfig


class ProgrammsConfig(AppConfig):
    name = 'programms'
