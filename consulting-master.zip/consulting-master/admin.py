from wagtail.contrib.modeladmin.options import ModelAdmin,modeladmin_register

