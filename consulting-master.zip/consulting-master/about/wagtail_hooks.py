from wagtail.contrib.modeladmin.options import (
    ModelAdmin, modeladmin_register)

from about.models import *
from blogs.models import Employee


class SliderAdmin(ModelAdmin):
    model = Slider
    menu_label = 'Orqa rasm(biz haqimizda)'  # ditch this to use verbose_name_plural from model
    menu_icon = 'image'  # change as required
    menu_order = 3  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view

    list_display = ('id', 'big_title', 'image')
    list_filter = ('id',)
    search_fields = ('id', 'big_title', )


modeladmin_register(SliderAdmin)


class MiddleSectionAdmin(ModelAdmin):
    model = MiddleSection
    menu_label = 'Biz haqimizda'  # ditch this to use verbose_name_plural from model
    menu_icon = 'title'  # change as required
    menu_order = 5  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view
    list_display = ('id', )
    # list_filter = ('id', 'title_left', 'title_right')
    search_fields = ('id', 'title_left', 'title_right')


modeladmin_register(MiddleSectionAdmin)


class ChoiceAdmin(ModelAdmin):
    model = Choice
    menu_label = 'Imkoniyatlar'  # ditch this to use verbose_name_plural from model
    menu_icon = 'view'  # change as required
    menu_order = 9  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view
    list_display = ('id', 'number', 'title')
    # list_filter = ('id', 'number', 'title')
    search_fields = ('id', 'number', 'title')


modeladmin_register(ChoiceAdmin)
