from django.db import models

# Create your models here.
from wagtail.admin.edit_handlers import FieldPanel
from wagtail.core.fields import RichTextField


class Slider(models.Model):
    big_title = models.TextField("Katta Slayder")
    image = models.ImageField("Rasm",default='default.jpg', upload_to='about_page_images')

    class Meta:
        verbose_name = 'Slider'
        verbose_name_plural = "Sliders"

    panels = [
        FieldPanel('big_title'),
        FieldPanel('image'),
    ]

    def __str__(self):
        return self.big_title


class MiddleSection(models.Model):
    title_left = RichTextField("Chap tarafdagi tafsif")
    title_right = RichTextField("O'ng tarafdagi tafsif")
    photo = models.ImageField("Rasm",default='default.jpg', upload_to='about_page_images')

    class Meta:
        verbose_name = "qo'shish"
        verbose_name_plural = "qo'shish"

    panels = [
        FieldPanel('title_left'),
        FieldPanel('title_right'),
        FieldPanel('photo'),
    ]

    def __str__(self):
        return self.title_left


class Choice(models.Model):
    number = models.IntegerField("Mavjud Dastur soni",default=1)
    title = models.CharField("Dastur tavsifi",max_length=100)

    class Meta:
        verbose_name = 'shans'
        verbose_name_plural = 'shanslar'

    panels = [
        FieldPanel('number'),
        FieldPanel('title'),
    ]

    def __str__(self):
        return self.title
