from django.db import models
from wagtail.admin.edit_handlers import FieldPanel
from wagtail.images.edit_handlers import ImageChooserPanel

from common.models import Base
from wagtail.core.fields import RichTextField


class BlogPageSlider(models.Model):
    title = models.CharField("Tavsif",max_length=200)
    image = models.ImageField("Rasm")

    class Meta:
        verbose_name = 'Slider'
        verbose_name_plural = "Sliders"

    panels = [
        FieldPanel('title'),
        FieldPanel('image'),
    ]

    def __str__(self):
        return self.title


class Employee(Base):
    full_name = models.CharField("familiya,ism",max_length=255)
    position = models.CharField("lavozim",max_length=255)
    image = models.ImageField("rasm",default='default.jpg', upload_to='blog_images')

    class Meta:
        verbose_name = 'Hodim'
        verbose_name_plural = "Hodimlar"

    panels = [
        FieldPanel('full_name'),
        FieldPanel('position'),
        FieldPanel('image'),
    ]

    def __str__(self):
        return self.full_name


class Blog(Base):
    photo = models.ImageField("rasm",default='default.jpg', upload_to='blog_images')
    title = models.CharField("Sarlavha",max_length=150)
    short_description = RichTextField("qisqa tavsif", max_length=350, default="max 300 belgi")
    full_description = RichTextField("to'liq tavsif", default="(max 3000 ta belgi yozilishi kerak)")

    class Meta:
        verbose_name = 'Post'
        verbose_name_plural = "Postlar"

    panels = [
        FieldPanel('title'),
        FieldPanel('short_description'),
        FieldPanel('full_description'),
        FieldPanel('photo'),

    ]

    def __str__(self):
        return self.title
