from django.shortcuts import render
from django.views.generic import TemplateView

from django.views.generic import (
    ListView,
    DetailView
)
from .models import *


class BlogListView(ListView):
    queryset = Blog.objects.all()
    template_name = 'blog/blog.html'
    context_object_name = 'blog_lists'
    paginate_by = 6


class BlogDetailView(DetailView):
    # model = Blog.objects.all()
    queryset = Blog.objects.all()
    template_name = 'blog/blog_detail.html'
