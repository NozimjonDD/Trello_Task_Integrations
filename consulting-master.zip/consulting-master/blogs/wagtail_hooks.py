from wagtail.contrib.modeladmin.options import (
    ModelAdmin, modeladmin_register)

from blogs.models import Employee, Blog, BlogPageSlider


class SliderAdmin(ModelAdmin):
    model = BlogPageSlider
    menu_label = 'Orqa_rasm(Aloqa)'  # ditch this to use verbose_name_plural from model
    menu_icon = 'image'  # change as required
    menu_order = 8  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view
    list_display = ('id', 'title',)
    # list_filter = ('id', 'big_title', 'title')
    search_fields = ('id', 'title')


modeladmin_register(SliderAdmin)


class EmployeeAdmin(ModelAdmin):
    model = Employee
    menu_label = 'Hodimlar'  # ditch this to use verbose_name_plural from model
    menu_icon = 'user'  # change as required
    menu_order = 4  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view
    list_display = ('id', 'full_name', )
    # list_filter = ('id', 'full_name', 'position')
    search_fields = ('id', 'full_name', 'position')


modeladmin_register(EmployeeAdmin)


class BlogAdmin(ModelAdmin):
    model = Blog
    menu_label = 'Yangiliklar'  # ditch this to use verbose_name_plural from model
    menu_icon = 'doc-full'  # change as required
    menu_order = 7  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view
    list_display = ('id', 'title',)
    # list_filter = ('id', 'description')
    search_fields = ('id', 'description')


modeladmin_register(BlogAdmin)
