from wagtail.contrib.modeladmin.options import (
    ModelAdmin, modeladmin_register)

from .models import *


class HeaderAdmin(ModelAdmin):
    model = Header
    menu_label = 'Asosiy(Sarlavha)'  # ditch this to use verbose_name_plural from model
    menu_icon = 'user'  # change as required
    menu_order = 10  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view
    list_display = ('id', 'name', 'order')
    list_filter = ('id', 'name',)
    search_fields = ('id', 'name',)


class HomeSliderAdmin(ModelAdmin):
    model = HomeSlider
    menu_label = 'Oraqa rasm(Asosiy)'  # ditch this to use verbose_name_plural from model
    menu_icon = 'image'  # change as required
    menu_order = 12  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view
    list_display = ('id', 'title', 'big_title', 'image')
    list_filter = ('id', 'title','big_title', 'image')
    search_fields = ('id', 'big_title','title',)


class HomeOfferAdmin(ModelAdmin):
    model = HomeOffer
    menu_label = 'Asosiy(Biz haqimizda)'  # ditch this to use verbose_name_plural from model
    menu_icon = 'pilcrow'  # change as required
    menu_order = 6  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view
    list_display = ('id', 'title',)
    list_filter = ('id', 'title',)
    search_fields = ('id', 'title',)

class SertificateAdmin(ModelAdmin):
    model = Sertificate
    menu_label = 'Sertikatlar'  # ditch this to use verbose_name_plural from model
    menu_icon = 'doc-full'  # change as required
    menu_order = 12   # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view
    list_display = ('id', 'title',)
    list_filter = ('id', 'title', )
    search_fields = ('id', 'title', )


modeladmin_register(HeaderAdmin)
modeladmin_register(HomeOfferAdmin)
modeladmin_register(SertificateAdmin)
modeladmin_register(HomeSliderAdmin)
