from django.urls import path
from .views import *

app_name='home_page'

urlpatterns = [
    path('', HomeTemplateView.as_view(), name='home_page_list'),
    path('about/', AboutTemplateView.as_view(), name='about'),
    path('sertificate/', SertificateListView.as_view(), name='sertificate'),
    path('sertificate_detail/<int:pk>/', BlogDetailView.as_view(), name='sertificate_detail'),
]