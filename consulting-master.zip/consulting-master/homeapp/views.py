from django.shortcuts import render
from django.views.generic import TemplateView,ListView,DetailView
from .models import *

class HomeTemplateView(TemplateView):
    template_name = 'base/base.html'


class AboutTemplateView(TemplateView):
    template_name = "about/about.html"


class SertificateListView(ListView):
    model = Sertificate
    template_name = "sertificate/sertificate.html"
    paginate_by = 6


class BlogDetailView(DetailView):
    # model = Blog.objects.all()
    queryset = Sertificate.objects.all()
    template_name = 'sertificate/sertificate_detail.html'