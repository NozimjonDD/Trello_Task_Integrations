from django.db import models
from wagtail.admin.edit_handlers import FieldPanel
from wagtail.core.fields import RichTextField


class Header(models.Model):
    name=models.CharField("Sarlavha nomi",max_length=255)
    order=models.IntegerField("Tartib raqam",default=1)
    slug = models.SlugField("o'zgartirilmaydigan sarlavha nomi",max_length=255)

    class Meta:
        ordering = ('order',)
        verbose_name = 'Bosh Sarfavha'
        verbose_name_plural = 'Bosh Sarlavhalar'

    panels = [
        FieldPanel('name'),
        FieldPanel('order'),
        FieldPanel('slug')
    ]

    def __str__(self):
        return self.name


class HomeSlider(models.Model):
    title = models.CharField(max_length=255)
    big_title = models.CharField(max_length=255)
    image = models.ImageField(default='default.jpg', upload_to='some_slider_images')

    class Meta:
        verbose_name = 'Home slider'
        verbose_name_plural = 'Home slider'

    panels = [
        FieldPanel('title'),
        FieldPanel('big_title'),
        FieldPanel('image'),

    ]

    def __str__(self):
        return self.title


class HomeOffer(models.Model):
    title=models.CharField("Sarlavha",max_length=255)
    text1=RichTextField("Birinchi tavsif")
    text2=RichTextField("Ikkinchi tavsif")
    text3=RichTextField("Uchinchi tavsif")
    img = models.ImageField("Rasm",default='default.jpg', upload_to='home')


class Sertificate(models.Model):
    title=models.CharField("Tavsiv",max_length=255)
    img = models.ImageField("Rasm",default='default.jpg', upload_to='home')

