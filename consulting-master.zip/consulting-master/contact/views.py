from django.conf import settings
from django.core.mail import send_mail
from django.shortcuts import render

from .models import *
from django.views.generic import (
    ListView
)


class ContactPageListView(ListView):  # bu view horzcha ishlatilmayapdi
    queryset = ContactPage.objects.all()
    template_name = 'contact/contact.html'
    context_object_name = 'map_lists'


def index(request):
    if request.method == "POST":
        contact = Message()
        name = request.POST['name']
        email = request.POST['email']
        title = request.POST['title']
        message = request.POST['message']

        # list1 = []
        # list1.append(title)
        # list1.append(name)

        send_mail(
            name,
            message,

            settings.EMAIL_HOST_USER,
            ["nozimfromandijan@gmail.com", email],
            fail_silently=False,

        )
        contact.sender_full_name = name
        contact.sender_email = email
        contact.text = title
        contact.subject = message
        print(name)

        contact.save()

        # return HttpResponse("<h1> Qabul qilindi !</h1> ")

    return render(request, "contact/contact.html")
