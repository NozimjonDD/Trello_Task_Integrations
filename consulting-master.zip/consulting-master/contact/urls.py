from django.urls import path
from .views import *

app_name = 'contact'

urlpatterns = [
    path('contact1/', ContactPageListView.as_view(), name='nomsiz'),
    path('', index, name='contact_map_list'),
]
