from django.db import models
from wagtail.admin.edit_handlers import FieldPanel
from wagtail.admin.edit_handlers import FieldPanel
from wagtail.core.fields import RichTextField
from common.models import Base


class Message(Base):
    text = models.TextField("habar")
    sender_full_name = models.CharField("Yuboruchi to'liq familiya, ismi",max_length=255)
    sender_email = models.EmailField("Yuboruvchi elektron manzili",max_length=255)
    subject = models.TextField("Mavzu",max_length=500)


class ContactPage(models.Model):
    address = RichTextField("manzil", default="bu yerda 2ta title")
    street = models.CharField("Ko'cha nomi",max_length=300)
    phone = models.IntegerField("Telefon raqam")
    email = models.EmailField("Elektron manzil",max_length=50)
    work_time = models.CharField("ish vaqti",max_length=50, default="9:00-18:00")
    map = models.TextField("Karta 650x510",default="xarita razmeri 650510 bo'lishi kere")

    class Meta:
        verbose_name = 'xarita'
        verbose_name_plural = "xaritalar"

    panels = [
        FieldPanel('address'),
        FieldPanel('street'),
        FieldPanel('phone'),
        FieldPanel('email'),
        FieldPanel('work_time'),
        FieldPanel('map'),
    ]

    def __str__(self):
        return self.address


class ContactSlider(Base):
    title=models.CharField(max_length=255)
    img = models.ImageField("rasm",default='default.jpg', upload_to='program_images')