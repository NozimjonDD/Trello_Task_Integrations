from wagtail.contrib.modeladmin.options import (
    ModelAdmin, modeladmin_register)
from .models import *


class ContactPageAdmin(ModelAdmin):
    model = ContactPage
    menu_label = 'Aloqa(xarita)'  # ditch this to use verbose_name_plural from model
    menu_icon = 'form'  # change as required
    menu_order = 11  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view

    list_display = ('id', 'street', 'phone', 'email', 'work_time')
    list_filter = ('id',)
    search_fields = ('id', 'address', 'street', 'phone', 'email', 'work_time', 'map')


class ContactSliderAdmin(ModelAdmin):
    model = ContactSlider
    menu_label = 'Orqa rasm(Aloqa)'  # ditch this to use verbose_name_plural from model
    menu_icon = 'image'  # change as required
    menu_order = 14  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view

    list_display = ('id', 'title',)
    list_filter = ('id',)
    search_fields = ('id', 'title')


class MessageAdmin(ModelAdmin):
    model = Message
    menu_label = 'Xabarlar'  # ditch this to use verbose_name_plural from model
    menu_icon = 'mail'  # change as required
    menu_order = 17  # will put in 1st place (000 being 1st, 100 2nd)
    add_to_settings_menu = False  # or True to add your model to the Settings sub-menu
    exclude_from_explorer = False  # or True to exclude pages of this type from Wagtail's explorer view

    list_display = ('id', 'text', 'sender_full_name', 'sender_email', 'subject')
    list_filter = ('id',)
    search_fields = ('id', 'text', 'sender_full_name', 'sender_email', 'subject')


modeladmin_register(ContactPageAdmin)
modeladmin_register(ContactPageAdmin)
modeladmin_register(MessageAdmin)
