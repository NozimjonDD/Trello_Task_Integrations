from django.conf import settings
from django.core.mail import send_mail
from django.shortcuts import render
from django.views.generic import (
    ListView
)

from common.models import *
from contact.models import Message


class ContactListView(ListView):
    queryset = Contact.objects.first()
    template_name = 'contact/contact.html'
    context_object_name = 'contact'

def index(request):
    if request.method == "POST":
        # contact = Contact(request.POST)
        contact = Message()
        name = request.POST['name']
        email = request.POST['email']
        title = request.POST['title']
        message = request.POST['message']

        # list1 = []
        # list1.append(title)
        # list1.append(name)

        # print(list1)

        send_mail(
            name,
            message,

            settings.EMAIL_HOST_USER,
            [email, title],
            fail_silently=False,

        )
        contact.sender_full_name = name
        contact.sender_email = email
        contact.text = title
        contact.subject = message
        print(name)
        print(title)
        print(email)
        print(message)

        contact.save()

        # return HttpResponse("<h1> Qabul qilindi !</h1> ")

    return render(request, "contact/contact.html")