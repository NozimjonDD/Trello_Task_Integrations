from about.models import Slider, MiddleSection, Choice
from blogs.models import Employee, Blog, BlogPageSlider
from contact.models import ContactPage,ContactSlider
from programms.models import *
from .models import *
from homeapp.models import *


def get_home_elements(request):
    all_programs = Program.objects.all()[:6]
    all_countries=ProgramCountry.objects.all()
    all_categories=ProgramCategory.objects.all()
    employees = Employee.objects.all()
    about_slider = Slider.objects.first()
    titles = MiddleSection.objects.all()
    choices = Choice.objects.all()
    blogs = Blog.objects.all()[:6]
    blog_slider = BlogPageSlider.objects.first()
    contact_footer = Contact.objects.first()
    headers = Header.objects.all()
    about_home = HomeOffer.objects.first()
    contact_maps = ContactPage.objects.all()
    all_sertificates=Sertificate.objects.all()[:3]
    home_slider = HomeSlider.objects.first()
    program_slider=ProgramSlider.objects.first()
    contact_slider=ContactSlider.objects.first()


    return {
        'all_programs': all_programs,
        'employees': employees,
        'about_slider': about_slider,
        'titles': titles,
        'choices': choices,
        'blogs': blogs,
        'blog_slider': blog_slider,
        'contact_footer': contact_footer,
        'headers': headers,
        'about_home': about_home,
        'contact_maps': contact_maps,
        'all_sertificates':all_sertificates,
        'home_slider': home_slider,
        'program_slider':program_slider,
        'contact_slider':contact_slider,
        'all_countries':all_countries,
        'all_categories':all_categories,
    }
